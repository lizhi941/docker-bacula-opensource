#
# See the file <bacula-source>/examples/sample-query.sql
#  for some sample queries. 
#
# 1
:The default file is empty, see sample-query.sql (in /opt/bacula/scripts or <bacula-source>/examples) for samples
SELECT 'See sample-query.sql (in /opt/bacula/scripts or <bacula-source>/examples) for samples' AS Info;

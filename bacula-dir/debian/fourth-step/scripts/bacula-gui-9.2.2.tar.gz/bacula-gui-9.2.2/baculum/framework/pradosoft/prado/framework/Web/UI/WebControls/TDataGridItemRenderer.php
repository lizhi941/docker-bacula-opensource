<?php
/**
 * TDataGridItemRenderer class file
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @link https://github.com/pradosoft/prado
 * @copyright Copyright &copy; 2005-2016 The PRADO Group
 * @license https://github.com/pradosoft/prado/blob/master/LICENSE
 * @package Prado\Web\UI\WebControls
 */

namespace Prado\Web\UI\WebControls;

/**
 * TDataGridItemRenderer class
 *
 * TDataGridItemRenderer can be used as a convenient base class to
 * define an item renderer class specific for {@link TDataGrid}.
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @package Prado\Web\UI\WebControls
 * @since 3.1.0
 */
class TDataGridItemRenderer extends TItemDataRenderer
{
}
